# OrganGrinder

- [Project Instructions][p-i]

[p-i]: https://github.com/appacademy/react-flux-curriculum/blob/master/projects/w7d3_organ.md
